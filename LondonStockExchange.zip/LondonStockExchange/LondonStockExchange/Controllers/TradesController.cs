﻿using Models.Dtos;
using Interfaces.Repositories.Exchange;
using Microsoft.AspNetCore.Mvc;

namespace LondonStockExchange.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TradesController : ControllerBase
    {
        private readonly ITradeRepository _tradeRepository;
        private readonly ILogger<TradesController> _logger;

        public TradesController(
            ILogger<TradesController> logger,
            ITradeRepository tradeRepository)
        {
            _logger = logger;
            _tradeRepository = tradeRepository;
        }

        [HttpPost]
        public IActionResult Post([FromBody] Trade trade)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _tradeRepository.AddTrade(trade);
                }
                catch (ArgumentNullException argumentEx)
                {
                    _logger.LogError(argumentEx, "Trade not valid", trade);
                    return BadRequest();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Critical Error", trade);
                    return BadRequest();
                }
                return Accepted();
            }
            else
            {
                _logger.LogError("Trade not valid", trade);
                return BadRequest();
            }
        }

    }
}
