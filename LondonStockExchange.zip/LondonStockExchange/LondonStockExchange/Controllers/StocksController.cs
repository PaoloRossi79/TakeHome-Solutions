﻿using Interfaces.Repositories.Exchange;
using Microsoft.AspNetCore.Mvc;

namespace LondonStockExchange.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StocksController : ControllerBase
    {
        private readonly IStockRepository _stockRepository;
        private readonly ILogger<StocksController> _logger;

        public StocksController(
            ILogger<StocksController> logger,
            IStockRepository stockRepository)
        {
            _logger = logger;
            _stockRepository = stockRepository;
        }

        [HttpGet()]
        public IActionResult Get()
        {
           return  Get(null);
        }


        [HttpGet("{stocks}")]
        public IActionResult Get(string stocks)
        {
            try
            {
                string[] values = string.IsNullOrEmpty(stocks) ? null : stocks.ToUpper().Split(',');

              return Ok(_stockRepository.GetStocks(values));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Critical Error", stocks);
                return BadRequest();
            }
        }

    }
}
