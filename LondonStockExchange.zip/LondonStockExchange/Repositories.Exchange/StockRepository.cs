﻿using Interfaces.Repositories.Exchange;
using Microsoft.Extensions.Caching.Distributed;
using Dtos = Models.Dtos;
using Database.ExchangeDb;
using Microsoft.Extensions.Configuration;
using Models.Configuration;
using System.Text.Json;

namespace Repositories.Exchange
{
    public class StockRepository : IStockRepository
    {
        private readonly IDistributedCache _cache;
        private readonly Settings _settings;
        private readonly DistributedCacheEntryOptions _defaultCacheEntryOptions;

        public StockRepository(
            IDistributedCache cache,
            IConfiguration configuration)
        {
            _cache = cache;
            _settings = configuration.GetSection("Settings").Get<Settings>();
            _defaultCacheEntryOptions = new DistributedCacheEntryOptions()
               .SetSlidingExpiration(TimeSpan.FromMilliseconds(_settings.CacheSlidingExpiration ?? 100))
               .SetAbsoluteExpiration(TimeSpan.FromMilliseconds(_settings.CacheAbsoluteExpiration ?? 1000));
        }

        public Dtos.Stock[] GetStocks(string[] stockTickerSymbols)
        {
            Dtos.Stock[] result;
            string key;

            if (stockTickerSymbols is null || !stockTickerSymbols.Any())
            {
                key = $"Stock_All";
            }
            else
            {
                Array.Sort(stockTickerSymbols);
                key = $"Stock_{String.Join(',', stockTickerSymbols).ToUpper()}";
            }

            byte[] cachedValue = _cache.Get(key);

            if (cachedValue is not null)
            {
                result = JsonSerializer.Deserialize(cachedValue, Dtos.StockJsonContext.Default.StockArray);
            }
            else
            {
                using (ExchangeDbContext dbContext = new())
                {
                    result = dbContext.Trades.Where(x =>
                            stockTickerSymbols == null ||
                            !stockTickerSymbols.Any() ||
                            stockTickerSymbols.Contains(x.StockTickerSymbol))
                                  .GroupBy(g => g.StockTickerSymbol)
                                  .Select(r => new Dtos.Stock()
                                  {
                                      StockTickerSymbol = r.Key,
                                      Value = r.Sum(s => s.Shares * s.Price).ToString("C")
                                  }).ToArray();
                }
                if (result is not null)
                {
                    byte[] value = JsonSerializer.SerializeToUtf8Bytes(result, Dtos.StockJsonContext.Default.StockArray);
                    _cache.Set(key, value, _defaultCacheEntryOptions);
                }
            }

            return result;
        }

    }
}