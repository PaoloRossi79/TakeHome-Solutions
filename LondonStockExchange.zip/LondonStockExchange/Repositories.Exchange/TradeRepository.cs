﻿using Interfaces.Repositories.Exchange;
using Dtos = Models.Dtos;
using Database.ExchangeDb;

namespace Repositories.Exchange
{
    public class TradeRepository : ITradeRepository
    {
        public void AddTrade(Dtos.Trade trade)
        {
            if (trade is null) { throw new ArgumentNullException(nameof(trade)); }

            using (ExchangeDbContext dbContext = new())
            {
                var broker = dbContext.Brokers.First(x => x.BrokerId == trade.BrokerId);

                dbContext.Trades.Add(new()
                {
                    Broker = broker,
                    Price = trade.Price,
                    Shares = trade.Shares,
                    StockTickerSymbol = trade.StockTickerSymbol.Trim().ToUpper(),
                    TimeStamp = DateTimeOffset.UtcNow
                });

                dbContext.SaveChanges();
            }
        }



    }
}