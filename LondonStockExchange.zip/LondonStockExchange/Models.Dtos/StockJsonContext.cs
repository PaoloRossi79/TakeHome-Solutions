﻿using System.Text.Json.Serialization;

namespace Models.Dtos
{
    [JsonSerializable(typeof(Stock[]))]
    [JsonSourceGenerationOptions(
        GenerationMode = JsonSourceGenerationMode.Default,
        PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase)]
    public partial class StockJsonContext : JsonSerializerContext
    {

    }

}
