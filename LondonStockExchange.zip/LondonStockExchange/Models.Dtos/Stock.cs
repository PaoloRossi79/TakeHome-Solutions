﻿
namespace Models.Dtos
{
    public class Stock
    {
      public string StockTickerSymbol { get; set; }
      public string Value { get; set; }
    }
}
