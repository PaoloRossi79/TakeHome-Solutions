﻿using System.ComponentModel.DataAnnotations;

namespace Models.Dtos
{
    public class Trade
    {
        [Required]
        public ulong BrokerId { get; set; }
        [Required]
        public string StockTickerSymbol { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public decimal Shares { get; set; }
    }
}