﻿namespace Models.Configuration
{
    public class Settings
    {
        public uint? CacheSlidingExpiration { get; set; } // milliseconds
        public uint? CacheAbsoluteExpiration { get; set; } // milliseconds
    }
}