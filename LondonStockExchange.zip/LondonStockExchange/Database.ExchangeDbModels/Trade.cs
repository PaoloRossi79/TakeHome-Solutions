﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Database.ExchangeDbModels
{
    public class Trade
    {
        [Key]
        public ulong TradeId { get; set; }
        [MaxLength(100)]
        [Required]
        public string StockTickerSymbol { get; set; }
        [Required]
        [Column(TypeName = "decimal(38,8)")]
        public decimal Price { get; set; }
        [Required]
        [Column(TypeName = "decimal(38,8)")]
        public decimal Shares { get; set; }
        [Required]
        public DateTimeOffset TimeStamp { get; set; }
        [Required]
        public Broker Broker { get; set; }
    }
}