﻿using System.ComponentModel.DataAnnotations;

namespace Database.ExchangeDbModels
{
    public class Broker
    {
        [Key]
        public ulong BrokerId { get; set; }
        [MaxLength(500)]
        public string BrokerName { get; set; }
        public List<Trade> Trades { get; set; }
    }
}
