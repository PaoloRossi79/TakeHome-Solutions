﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Database.ExchangeDb
{
    public class ExchangeDbFactory : IDesignTimeDbContextFactory<ExchangeDbContext>
    {
        public ExchangeDbContext CreateDbContext(string[] args)
        {
            IConfiguration serverDbConfig = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var optionsBuilder = new DbContextOptionsBuilder<ExchangeDbContext>();
            optionsBuilder.UseSqlServer(serverDbConfig.GetConnectionString("DataSet"),
            sqlServerOptions => sqlServerOptions.CommandTimeout(serverDbConfig.GetValue<int?>("DbCommandTimeOut") ?? 30));

            return new ExchangeDbContext(optionsBuilder.Options);
        }
    }
}
