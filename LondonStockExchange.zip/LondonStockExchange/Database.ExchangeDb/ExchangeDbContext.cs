﻿using Database.ExchangeDbModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Database.ExchangeDb
{
    public class ExchangeDbContext : DbContext
    {
        public ExchangeDbContext(DbContextOptions<ExchangeDbContext> options) : base(options)
        {
        }

        public ExchangeDbContext() : base()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            IConfiguration serverDbConfig = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            optionsBuilder.UseSqlServer(serverDbConfig.GetConnectionString("DataSet"),
            sqlServerOptions => sqlServerOptions.CommandTimeout(serverDbConfig.GetValue<int?>("DbCommandTimeOut") ?? 30));
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {          
            builder.Entity<Trade>().HasIndex(s => s.StockTickerSymbol).IncludeProperties("Price", "Shares");
            builder.Entity<Trade>().Property(p => p.Price).HasPrecision(38, 8);
            builder.Entity<Trade>().Property(p => p.Shares).HasPrecision(38, 8);

        }
        public virtual DbSet<Broker> Brokers { get; set; }
        public virtual DbSet<Trade> Trades { get; set; }
    }
}