﻿using Models.Dtos;

namespace Interfaces.Repositories.Exchange
{
    public interface IStockRepository
    {
        Stock[] GetStocks(string[] stockTickerSymbols);
    }
}