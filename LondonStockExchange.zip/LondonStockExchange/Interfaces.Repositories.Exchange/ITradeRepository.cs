﻿using Models.Dtos;

namespace Interfaces.Repositories.Exchange
{
    public interface ITradeRepository
    {
        void AddTrade(Trade trade);
    }
}