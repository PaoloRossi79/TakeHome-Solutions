
--Create new Database

create database LondonStockExDB

use LondonStockExDB

--Create Stock table

create table Stocks(ID int identity(1,1) primary key, StockName varchar(100), StockTicker varchar(5) unique, StockCurrentPrice decimal)

--Create Broker table

create table Brokers(ID int identity(1,1) primary key, BrokerName varchar(100))

--Create StockTransactionTable

create table StockTransactions(ID int identity(1,1) primary key, StockID int foreign key references Stocks(ID), BrokerID int foreign key references Brokers(ID), NumberOfShares int, StockSellingPrice decimal)

--Insert test data

insert into Stocks values('test stock1', 'TS1', 2)
insert into Stocks values('test stock2', 'TS2', 3)
insert into Stocks values('test stock3', 'TS3', 6)
insert into Stocks values('test stock4', 'TS4', 10)
insert into Stocks values('test stock5', 'TS5', 22.5)

insert into Brokers values('test broker1')
insert into Brokers values('test broker2')
insert into Brokers values('test broker3')
insert into Brokers values('test broker4')