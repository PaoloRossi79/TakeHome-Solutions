﻿using System.Collections.Generic;

namespace LondonStockExApi.Models
{
    public class StockValueRequest
    {
        public List<string> StockTickers { get; set; }
    }
}
