﻿namespace LondonStockExApi.Models
{
    public class StockValue
    {
        public string StockTicker { get; set; }
        public decimal? CurrentPrice { get; set; }
    }
}
