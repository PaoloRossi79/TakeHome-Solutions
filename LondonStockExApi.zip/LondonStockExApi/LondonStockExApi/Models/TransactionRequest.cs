﻿using System.ComponentModel.DataAnnotations;

namespace LondonStockExApi.Models
{
    public class TransactionRequest
    {
        [Required(AllowEmptyStrings = false)]
        public string StockTicker { get; set; }
        [Required(AllowEmptyStrings = false)]
        public decimal StockSellingPrice { get; set; }
        [Required(AllowEmptyStrings = false)]
        public int NumberOfShares { get; set; }
        [Required(AllowEmptyStrings = false)]
        public int BrokerID { get; set; }
    }
}
