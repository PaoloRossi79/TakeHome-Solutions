﻿using LondonStockExApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LondonStockExApi.Service
{
    public interface ILondonStockExService
    {
        Task<string> SaveTransactionAsync(TransactionRequest transactionRequest);
        Task<List<StockValue>> GetStockValuesAsync(StockValueRequest stockValueRequest);
    }
}
