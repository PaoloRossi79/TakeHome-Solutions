﻿using LondonStockExApi.EntityFramework;
using LondonStockExApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LondonStockExApi.Service
{
    public class LondonStockExService : ILondonStockExService
    {
        private readonly LondonStockExDBContext _londonStockExDBContext;
        public LondonStockExService(LondonStockExDBContext londonStockExDBContext)
        {
            _londonStockExDBContext = londonStockExDBContext;
        }
        public async Task<string> SaveTransactionAsync(TransactionRequest transactionRequest)
        {
            if (_londonStockExDBContext.Stocks.Any(x => x.StockTicker == transactionRequest.StockTicker))
            {
                if (_londonStockExDBContext.Brokers.Any(x => x.Id == transactionRequest.BrokerID))
                {
                    var stockId = _londonStockExDBContext.Stocks.Where(x => x.StockTicker == transactionRequest.StockTicker).FirstOrDefault().Id;
                    _londonStockExDBContext.StockTransactions.Add(new StockTransaction() { BrokerId = transactionRequest.BrokerID, StockId = stockId, NumberOfShares = transactionRequest.NumberOfShares, StockSellingPrice = transactionRequest.StockSellingPrice });
                    await _londonStockExDBContext.SaveChangesAsync();
                }
                else
                    return "Unknown broker";
            }
            else
                return "Unknown stock";

            return "success";
        }

        public async Task<List<StockValue>> GetStockValuesAsync(StockValueRequest stockValueRequest)
        {
            var stockValues = new List<StockValue>();
            var stocks = await _londonStockExDBContext.Stocks.ToListAsync();

            if (stockValueRequest.StockTickers == null || stockValueRequest.StockTickers.Count() == 0)
            {
                foreach (var stock in stocks)
                {
                    stockValues.Add(new StockValue() { StockTicker = stock.StockTicker, CurrentPrice = stock.StockCurrentPrice });
                }

                return stockValues;
            }
            else
            {
                foreach (var item in stockValueRequest.StockTickers)
                {
                    if (stocks.Any(x => x.StockTicker.Equals(item, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        var stock = stocks.Where(x => x.StockTicker.Equals(item, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                        stockValues.Add(new StockValue() { StockTicker = stock.StockTicker, CurrentPrice = stock.StockCurrentPrice });
                    }
                }

                return stockValues;
            }
        }
    }
}
