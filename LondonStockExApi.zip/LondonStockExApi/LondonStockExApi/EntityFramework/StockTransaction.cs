﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LondonStockExApi.EntityFramework
{
    public partial class StockTransaction
    {
        public int Id { get; set; }
        public int? StockId { get; set; }
        public int? BrokerId { get; set; }
        public int? NumberOfShares { get; set; }
        public decimal? StockSellingPrice { get; set; }

        public virtual Broker Broker { get; set; }
        public virtual Stock Stock { get; set; }
    }
}
