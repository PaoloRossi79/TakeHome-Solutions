﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LondonStockExApi.EntityFramework
{
    public partial class Broker
    {
        public Broker()
        {
            StockTransactions = new HashSet<StockTransaction>();
        }

        public int Id { get; set; }
        public string BrokerName { get; set; }

        public virtual ICollection<StockTransaction> StockTransactions { get; set; }
    }
}
