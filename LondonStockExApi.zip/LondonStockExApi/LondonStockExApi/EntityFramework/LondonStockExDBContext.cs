﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace LondonStockExApi.EntityFramework
{
    public partial class LondonStockExDBContext : DbContext
    {
        public LondonStockExDBContext()
        {
        }

        public LondonStockExDBContext(DbContextOptions<LondonStockExDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Broker> Brokers { get; set; }
        public virtual DbSet<Stock> Stocks { get; set; }
        public virtual DbSet<StockTransaction> StockTransactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Broker>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BrokerName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Stock>(entity =>
            {
                entity.HasIndex(e => e.StockTicker, "UQ__Stocks__3D76E2312E0BF5E9")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.StockCurrentPrice).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.StockName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StockTicker)
                    .HasMaxLength(5)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StockTransaction>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BrokerId).HasColumnName("BrokerID");

                entity.Property(e => e.StockId).HasColumnName("StockID");

                entity.Property(e => e.StockSellingPrice).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.Broker)
                    .WithMany(p => p.StockTransactions)
                    .HasForeignKey(d => d.BrokerId)
                    .HasConstraintName("FK__StockTran__Broke__31EC6D26");

                entity.HasOne(d => d.Stock)
                    .WithMany(p => p.StockTransactions)
                    .HasForeignKey(d => d.StockId)
                    .HasConstraintName("FK__StockTran__Stock__30F848ED");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
