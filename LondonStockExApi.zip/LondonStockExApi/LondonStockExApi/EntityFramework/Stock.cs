﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LondonStockExApi.EntityFramework
{
    public partial class Stock
    {
        public Stock()
        {
            StockTransactions = new HashSet<StockTransaction>();
        }

        public int Id { get; set; }
        public string StockName { get; set; }
        public string StockTicker { get; set; }
        public decimal? StockCurrentPrice { get; set; }

        public virtual ICollection<StockTransaction> StockTransactions { get; set; }
    }
}
