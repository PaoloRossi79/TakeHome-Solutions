﻿using LondonStockExApi.Models;
using LondonStockExApi.Service;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LondonStockExApi.Controllers
{
    [Route("api")]
    [ApiController]
    public class StockExController : ControllerBase
    {
        private readonly ILondonStockExService _londonStockExService;
        public StockExController(ILondonStockExService londonStockExService)
        {
            _londonStockExService = londonStockExService;
        }

        [HttpPost("stocktransaction")]
        public async Task<ActionResult<string>> StockTransaction([FromBody] TransactionRequest request)
        {
            var response = await _londonStockExService.SaveTransactionAsync(request);
            if (response != "success")
                return BadRequest(response);
            else
                return Ok("Success");
        }

        [HttpPost("getstockvalue")]
        public async Task<ActionResult<List<StockValue>>> GetStockValue([FromBody] StockValueRequest request)
        {
            return await _londonStockExService.GetStockValuesAsync(request);
        }
    }
}
